# An Angular Lineman Setup

# Installation Instructions

* make sure you have lineman installed globally `npm install -g lineman`
* `npm install`
* `lineman run`
* make sure you are running rails from the directory up `bundle exec rails s`