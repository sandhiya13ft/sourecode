# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
RailsBackend::Application.config.secret_key_base = '08ba90d2a8b8082d2390577e73efa1c6551a8337179c545e2f328f366b2ac4c1c689ff8f6be4c8c6cdd06d5e852638a99eb968dd17ce5a1db08503e1e3c8abfb'
