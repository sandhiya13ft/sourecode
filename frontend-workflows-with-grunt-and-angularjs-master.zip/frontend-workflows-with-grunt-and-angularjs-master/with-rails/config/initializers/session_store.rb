# Be sure to restart your server when you modify this file.

RailsBackend::Application.config.session_store :cookie_store, key: '_rails-backend_session'
