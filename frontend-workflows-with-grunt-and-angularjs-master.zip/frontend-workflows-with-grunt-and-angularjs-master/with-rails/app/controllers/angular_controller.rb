class AngularController < ApplicationController
  def index

  end
end