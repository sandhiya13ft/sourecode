var app = angular.module('app', []);

// controller here

// directive here
