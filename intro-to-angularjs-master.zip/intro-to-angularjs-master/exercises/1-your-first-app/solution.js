// app.js
angular.module('app', []);

// index.html
<html lang="en" ng-app="app">
